function validateForm() {
  let fristName = document.forms["signup"]["first-name"];
  let lastName = document.forms["signup"]["last-name"];
  let username = document.forms["signup"]["username"];
  let password = document.forms["signup"]["pwd"];
  let cpassword = document.forms["signup"]["pwd-confirm"];

  let nameRule = /[A-Z][a-zA-Z]*$/;
  let userRule =/^[a-zA-z]...../;
  let errorMsg = [];
  let errorBox = document.querySelector('#error-box');
  errorBox.innerHTML = '';

  if (!nameRule.test(fristName.value)){
    errorMsg.push("First Name: Must start with a cap and only alphabet allowed"); 
    fristName.focus();
  }

  if (!nameRule.test(lastName.value)){
    errorMsg.push("Last Name: Must start with a cap and only alphabet allowed"); 
    lastName.focus();
  }

  if( !userRule.test(username.value)){
    errorMsg.push("Username: must start with a letter, must have at least 6 characters"); 
    username.focus();
  }

  if (password.value.length != 6){
    errorMsg.push("Password: must be 6 characters long"); 
    cpassword.focus();
  }

  if ( !(/\d/.test(password.value))){
    errorMsg.push("Password: must have at least 1 digit"); 
    cpassword.focus();
  }

  if ( !(/[A-Z]/.test(password.value))){
    errorMsg.push("Password: must have at least 1 uppercase"); 
    cpassword.focus();
  }

  if ( !(/^[a-zA-Z]/.test(password.value))){
    errorMsg.push("Password: must start with a letter"); 
    cpassword.focus();
  }

  if (password.value !== cpassword.value){
    errorMsg.push("Confirm Password: Password and Confirm Password did not match"); 
    cpassword.focus();
  }

  if (errorMsg.length){
    let count = (errorMsg.length > 8) ? 8: errorMsg.length;
    let errorBox = document.querySelector('#error-box');
    
    for (let i = 0; i < count; i++) {
      errorBox.innerHTML += errorMsg[i] + '<br><hr><br>';
    }
  }

  return (errorMsg.length) ? false : true; 
};
