/*
 * This is a JavaScript Scratchpad.
 *
 * Enter some JavaScript, then Right Click or choose from the Execute Menu:
 * 1. Run to evaluate the selected text (Ctrl+R),
 * 2. Inspect to bring up an Object Inspector on the result (Ctrl+I), or,
 * 3. Display to insert the result in a comment after the selection. (Ctrl+L)
 */

/*********************************************************************************
* WEB222: Assignment 01
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually
* or electronically from any other source (including web sites)
* or distributed to other students.
*
* Name: Sijia Han      Student ID:  158923177        Date:  2019-01-28
*
********************************************************************************/

/*****************************
* Task 1: Description as Comments
*****************************/
//Infinity: Usually mean positive infinity, meaning it is greater than any other number.
console.log('1/0 = ', 1/0);
//Undefined: Did not assign a value to the variable.
var x;
console.log('var x = ', x);
//NaN: abbreviation for  Not-a-Number, also mean it is non-configurable, non-writeable property.
console.log('isNaN(NaN) = ', isNaN(NaN));;

/*****************************
* Task 2: Conversion
*****************************/
console.log("1010(binary) -> decimal = " + parseInt('1010',2));
console.log("AF(hex)  -> decimal = " + parseInt('AF', 16))
console.log("713(Octal) -> decimal = " + parseInt('713',8));

/*****************************
* Task 3: Celsius and Fahrenheit temperatures
*****************************/
//Formula : (0°C × 9/5) + 32 = 32°F
var celsius_temperature=0;
var convert_celsius_to_fahrenheit=celsius_temperature*9/5+32;
console.log(celsius_temperature+"°C is "+convert_celsius_to_fahrenheit+"°F");
var fahrenheit_temperature=180;
var convert_fahrenheit_to_celsius=(fahrenheit_temperature-32)*5/9;
console.log(fahrenheit_temperature+"°F is "+convert_fahrenheit_to_celsius+"°C");

/*****************************
* Task 4: Larger or largest number
*****************************/
function largerNum(number_1, number_2){
  return number_1>number_2 ? number_1 : number_2;
}
var greaterNum = function(number_1,number_2){
  return number_1>number_2 ? number_1 : number_2;
}
var a=0, b=1, c=0.1, d=0.01;
console.log("The larger number between " + a + " and " + b + " is " + largerNum(a,b) + ".");
console.log("The greater number between " + c + " and " + d + " is " + greaterNum(c,d) + ".");

/*****************************
* Task 5: Evaluator
*****************************/
function Evaluator(){
  var sum_scores=0;
  for(var i=0; i<arguments.length; i++){
    sum_scores+=arguments[i];
	console.log(i+1 + ". Number Score : " + arguments[i]);
  }
  return sum_scores/arguments.length>=25? "true" : "false";
}
console.log("Average scores greater than or equal to 25: " + Evaluator(25,25,24));
console.log("Average scores greater than or equal to 25: " + Evaluator(25,25,25,25));
console.log("Average scores greater than or equal to 25: " + Evaluator(12,23,34,45,67));

/*****************************
* Task 6: ShowMultiples
*****************************/
function showMultiples(num,numMultiples){
  for(var i=1; i<= numMultiples; i++){
    console.log(num + " x "+ i +" = " + num*i);
  }
}
var num=1, numMultiples=4;
console.log("if num = " + num + " and numMultiples = " + numMultiples + ", the function would output:");
showMultiples(num,numMultiples);

var num=2, numMultiples=5;
console.log("if num = " + num + " and numMultiples = " + numMultiples + ", the function would output:");
showMultiples(num,numMultiples);

var num=3, numMultiples=6;
console.log("if num = " + num + " and numMultiples = " + numMultiples + ", the function would output:");
showMultiples(num,numMultiples);

/*****************************
* Task 7: Closure/Self Invoking
*****************************/
/* function increment(){
  var counter = 100;
  function Increment_by_100(){
    counter+=100;
    return counter;
  }
return Increment_by_100;
var Increment = increment();
} */

var Increment = (function(){
  var counter = 100;  
  return function () {
	counter += 100;
	return counter;
  } })();

var time_1=Increment();
var time_2=Increment();
var time_3=Increment();
console.log("The final value for the third call: ",time_3);
